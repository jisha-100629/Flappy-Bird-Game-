import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class FlappyBird extends JPanel implements ActionListener,KeyListener{
	private static final int WIDTH = 1510;
	private static final int HEIGHT = 950;
	private static final int BIRD_WIDTH = 80;
	private static final int BIRD_HEIGHT = 90;
	private static final int PIPE_WIDTH = 100;
	private static final int PIPE_GAP = 300;
	private static final int INITIAL_PIPE_VELOCITY = 5;

	private Timer timer;
	private int birdY;
	private int birdVelocity;
	private int pipeVelocity = INITIAL_PIPE_VELOCITY;
	private int count;
	private int highScore = 0;
	private boolean gameStarted;
	private boolean gameOver;
    private boolean paused;

	private ArrayList<Rectangle> pipes;
	private Image backgroundImage;
   	private Image[] birdImages;
	private Image collisionImage;
	private int birdFrame = 0;
   	private Image topBranchImage;
    private Image bottomBranchImage;

	private boolean showInstructions = true;

	public FlappyBird(){
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        addKeyListener(this);
        
        birdY = HEIGHT / 2;
        birdVelocity = 0;
        pipes = new ArrayList<>();
        gameOver = false;
		gameStarted = false;
		paused = false;
        backgroundImage = new ImageIcon("background.png").getImage();
		birdImages = new Image[]{
			new ImageIcon("bird1.png").getImage(),
			new ImageIcon("bird2.png").getImage()
		};
		collisionImage = new ImageIcon("collision.png").getImage();
       	topBranchImage = new ImageIcon("topBranch.png").getImage();
        bottomBranchImage=new ImageIcon("bottomBranch.png").getImage();

        timer = new Timer(1000 / 60, this); 
       	timer.start();
   	}
	
	@Override
    public void actionPerformed(ActionEvent e){
		if (paused || !gameStarted){
			return;
		}
		if(gameOver){
    		return;
        }

        birdY += birdVelocity;
        birdVelocity += 1; 

        if (birdY > HEIGHT - BIRD_HEIGHT) {
           	birdY = HEIGHT - BIRD_HEIGHT;
    		birdVelocity = 0;
        }

        for (int i = 0; i < pipes.size(); i++){
            Rectangle pipe = pipes.get(i);
    		pipe.x -= pipeVelocity;

            if (pipe.x + PIPE_WIDTH < 0) {
                pipes.remove(i);
                i--;
                count ++;
				adjustDifficulty();
        	}
        }

        for (Rectangle pipe : pipes){
            if (pipe.intersects(new Rectangle(100, birdY, BIRD_WIDTH, BIRD_HEIGHT))){
                	gameOver = true;
            	}
        	}

            if (pipes.isEmpty() || pipes.get(pipes.size() - 1).x < WIDTH - 300){
                addPipe();
        	}
		    birdFrame = (birdFrame + 1) % birdImages.length;
        	repaint();
    }

    private void addPipe(){
    Random rand = new Random();
        int pipeHeight = rand.nextInt(HEIGHT / 2);
        pipes.add(new Rectangle(WIDTH, 0, PIPE_WIDTH, pipeHeight));
        pipes.add(new Rectangle(WIDTH, pipeHeight + PIPE_GAP, PIPE_WIDTH, HEIGHT - pipeHeight - PIPE_GAP));
    }

    private void adjustDifficulty() {
        if (count % 10 == 0) {
            pipeVelocity++;
        }
    }

    private void displayInstructions(Graphics g) {
        g.setFont(new Font("Comic Sans MS", Font.BOLD, 40));
        int yOffset = HEIGHT / 4;
        g.drawString("Press SPACE to Fly", WIDTH - 500, yOffset);
        g.drawString("Avoid touching obstacles", WIDTH - 500, yOffset + 50);
        g.drawString("Press P to Pause", WIDTH - 500, yOffset + 100);
        g.drawString("Press R to Restart", WIDTH - 500, yOffset + 150);
        g.drawString("Ready?", WIDTH - 500, yOffset + 250);
        g.drawString("Press SPACE to Start", WIDTH - 500, yOffset + 300);   
    }

    @Override
    public void keyTyped(KeyEvent e){
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            if (!gameStarted && showInstructions) {
                showInstructions = false;  
                gameStarted = true;
            }

            if (!gameOver && !paused) {
                birdVelocity = -15; 
            }
        } 
            
        else if (e.getKeyCode() == KeyEvent.VK_R && gameOver) {
            resetGame();
        } 
            
        else if (e.getKeyCode() == KeyEvent.VK_P) {
            paused = !paused;
        }
            
        else if (e.getKeyCode() == KeyEvent.VK_E) {
            System.exit(0); 
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    private void resetGame(){
        birdY = HEIGHT / 2;
        birdVelocity = 0;
        pipes.clear();
        pipeVelocity = INITIAL_PIPE_VELOCITY;
        gameOver = false;
        count = 0;
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, this);

        for (Rectangle pipe : pipes){
            if (pipe.y == 0){
                g.drawImage(topBranchImage, pipe.x, pipe.y, pipe.width, pipe.height, this);
            } 
                
            else {
                g.drawImage(bottomBranchImage, pipe.x, pipe.y, pipe.width, pipe.height, this);
            }
        }

        if (gameOver){
            g.drawImage(collisionImage, 100, birdY, BIRD_WIDTH, BIRD_HEIGHT, this);
        } 
            
        else {
            g.drawImage(birdImages[birdFrame], 100, birdY, BIRD_WIDTH, BIRD_HEIGHT, this);
        }

        if (showInstructions) {
            displayInstructions(g);
        }
            
        g.setColor(Color.black);
        g.setFont(new Font("Arial", Font.PLAIN, 40));
        g.drawString("Score: " + count / 2, WIDTH - 200, 50);

        highScore = Math.max(highScore, count);
        g.drawString("High Score: " + highScore / 2, 100, 50);

        if (gameOver){
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 60));
            g.drawString("Game Over!", WIDTH / 2 - 150, HEIGHT / 2);
            g.setFont(new Font("Comic Sans MS", Font.PLAIN, 40));
            g.drawString("Score: " + count / 2 + "  High Score: " + highScore / 2, WIDTH / 2 - 150, HEIGHT / 2 + 50);
            g.drawString("Press 'R' to Restart", WIDTH / 2 - 175, HEIGHT / 2 + 100);
            g.drawString("Press 'E' to Exit", WIDTH / 2 - 150, HEIGHT / 2 + 150);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Flappy Bird");
        FlappyBird game = new FlappyBird();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
